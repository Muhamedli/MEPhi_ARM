package ru.valkovets.engiteams.manipulator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManipulatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
